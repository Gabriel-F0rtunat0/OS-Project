#include "board.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdarg.h>

FILE *debugfile;

// Helper private function to find and kill pacman at specific position
static int find_and_kill_pacman(board_t *board, int new_x, int new_y)
{
    for (int p = 0; p < board->n_pacmans; p++)
    {
        pacman_t *pac = &board->pacmans[p];
        if (pac->pos_x == new_x && pac->pos_y == new_y && pac->alive)
        {
            pac->alive = 0;
            kill_pacman(board, p);
            return DEAD_PACMAN;
        }
    }
    return VALID_MOVE;
}

// Helper private function for getting board position index
static inline int get_board_index(board_t *board, int x, int y)
{
    return y * board->width + x;
}

static int init_board_locks(board_t *b)
{
    int n = b->width * b->height;
    for (int i = 0; i < n; i++)
    {
        if (pthread_rwlock_init(&b->board[i].rwlock, NULL) != 0)
            return -1;
    }
    return 0;
}

static void destroy_board_locks(board_t *b)
{
    int n = b->width * b->height;
    for (int i = 0; i < n; i++)
    {
        pthread_rwlock_destroy(&b->board[i].rwlock);
    }
}

// Helper private function for checking valid position
static inline int is_valid_position(board_t *board, int x, int y)
{
    return (x >= 0 && x < board->width) && (y >= 0 && y < board->height); // Inside of the board boundaries
}

static inline void lock_two(board_t *b, int i1, int i2)
{
    int a = i1 < i2 ? i1 : i2;
    int c = i1 < i2 ? i2 : i1;
    pthread_rwlock_wrlock(&b->board[a].rwlock);
    if (c != a)
        pthread_rwlock_wrlock(&b->board[c].rwlock);
}

static inline void unlock_two(board_t *b, int i1, int i2)
{
    int a = i1 < i2 ? i1 : i2;
    int c = i1 < i2 ? i2 : i1;
    if (c != a)
        pthread_rwlock_unlock(&b->board[c].rwlock);
    pthread_rwlock_unlock(&b->board[a].rwlock);
}

static void lock_column(board_t *b, int x)
{
    for (int y = 0; y < b->height; y++)
        pthread_rwlock_wrlock(&b->board[get_board_index(b, x, y)].rwlock);
}

static void unlock_column(board_t *b, int x)
{
    for (int y = b->height - 1; y >= 0; y--)
        pthread_rwlock_unlock(&b->board[get_board_index(b, x, y)].rwlock);
}

static void lock_row(board_t *b, int y)
{
    for (int x = 0; x < b->width; x++)
        pthread_rwlock_wrlock(&b->board[get_board_index(b, x, y)].rwlock);
}

static void unlock_row(board_t *b, int y)
{
    for (int x = b->width - 1; x >= 0; x--)
        pthread_rwlock_unlock(&b->board[get_board_index(b, x, y)].rwlock);
}

void sleep_ms(int milliseconds)
{
    struct timespec ts;
    ts.tv_sec = milliseconds / 1000;
    ts.tv_nsec = (milliseconds % 1000) * 1000000;
    nanosleep(&ts, NULL);
}

int move_pacman(board_t *board, int pacman_index, command_t *command)
{
    if (pacman_index < 0 || !board->pacmans[pacman_index].alive)
    {
        return DEAD_PACMAN; // Invalid or dead pacman
    }

    pacman_t *pac = &board->pacmans[pacman_index];
    int new_x = pac->pos_x;
    int new_y = pac->pos_y;

    // check passo
    if (pac->waiting > 0)
    {
        pac->waiting -= 1;
        return VALID_MOVE;
    }
    pac->waiting = pac->passo;

    char direction = command->command;

    if (direction == 'R')
    {
        char directions[] = {'W', 'S', 'A', 'D'};
        direction = directions[rand() % 4];
    }

    // Calculate new position based on direction
    switch (direction)
    {
    case 'W': // Up
        new_y--;
        break;
    case 'S': // Down
        new_y++;
        break;
    case 'A': // Left
        new_x--;
        break;
    case 'D': // Right
        new_x++;
        break;
    case 'T': // Wait
        if (command->turns_left == 1)
        {
            pac->current_move += 1; // move on
            command->turns_left = command->turns;
        }
        else
            command->turns_left -= 1;
        return VALID_MOVE;
    default:
        return INVALID_MOVE; // Invalid direction
    }

    // Logic for the WASD movement
    pac->current_move += 1;

    // Check boundaries
    if (!is_valid_position(board, new_x, new_y))
    {
        return INVALID_MOVE;
    }

    int new_index = get_board_index(board, new_x, new_y);
    int old_index = get_board_index(board, pac->pos_x, pac->pos_y);

    lock_two(board, old_index, new_index);

    char target_content = board->board[new_index].content;

    if (board->board[new_index].has_portal)
    {
        board->board[old_index].content = ' ';
        board->board[new_index].content = 'P';
        unlock_two(board, old_index, new_index);
        return REACHED_PORTAL;
    }

    // Check for walls
    if (target_content == 'W')
    {
        unlock_two(board, old_index, new_index);
        return INVALID_MOVE;
    }

    // Check for ghosts
    if (target_content == 'M')
    {
        kill_pacman(board, pacman_index);
        unlock_two(board, old_index, new_index);
        return DEAD_PACMAN;
    }

    // Collect points
    if (board->board[new_index].has_dot)
    {
        pac->points++;
        board->board[new_index].has_dot = 0;
    }

    board->board[old_index].content = ' ';
    pac->pos_x = new_x;
    pac->pos_y = new_y;
    board->board[new_index].content = 'P';
    unlock_two(board, old_index, new_index);
    return VALID_MOVE;
}

// Helper private function for charged ghost movement in one direction
static int move_ghost_charged_direction(board_t *board, ghost_t *ghost, char direction,
                                        int *new_x, int *new_y, int *final_index)
{
    int x = ghost->pos_x;
    int y = ghost->pos_y;
    *new_x = x;
    *new_y = y;
    *final_index = -1;

    int res = VALID_MOVE;
    int locked_row = -1, locked_col = -1;

    switch (direction)
    {
    case 'W':
        if (y == 0)
            return INVALID_MOVE;
        locked_col = x;
        lock_column(board, x);

        *new_y = 0;
        for (int i = y - 1; i >= 0; i--)
        {
            char t = board->board[get_board_index(board, x, i)].content;
            if (t == 'W' || t == 'M')
            {
                *new_y = i + 1;
                break;
            }
            if (t == 'P')
            {
                *new_y = i;
                res = find_and_kill_pacman(board, x, i);
                break;
            }
        }
        break;

    case 'S':
        if (y == board->height - 1)
            return INVALID_MOVE;
        locked_col = x;
        lock_column(board, x);

        *new_y = board->height - 1;
        for (int i = y + 1; i < board->height; i++)
        {
            char t = board->board[get_board_index(board, x, i)].content;
            if (t == 'W' || t == 'M')
            {
                *new_y = i - 1;
                break;
            }
            if (t == 'P')
            {
                *new_y = i;
                res = find_and_kill_pacman(board, x, i);
                break;
            }
        }
        break;

    case 'A':
        if (x == 0)
            return INVALID_MOVE;
        locked_row = y;
        lock_row(board, y);

        *new_x = 0;
        for (int j = x - 1; j >= 0; j--)
        {
            char t = board->board[get_board_index(board, j, y)].content;
            if (t == 'W' || t == 'M')
            {
                *new_x = j + 1;
                break;
            }
            if (t == 'P')
            {
                *new_x = j;
                res = find_and_kill_pacman(board, j, y);
                break;
            }
        }
        break;

    case 'D':
        if (x == board->width - 1)
            return INVALID_MOVE;
        locked_row = y;
        lock_row(board, y);

        *new_x = board->width - 1;
        for (int j = x + 1; j < board->width; j++)
        {
            char t = board->board[get_board_index(board, j, y)].content;
            if (t == 'W' || t == 'M')
            {
                *new_x = j - 1;
                break;
            }
            if (t == 'P')
            {
                *new_x = j;
                res = find_and_kill_pacman(board, j, y);
                break;
            }
        }
        break;

    default:
        return INVALID_MOVE;
    }

    *final_index = get_board_index(board, *new_x, *new_y);

    if (locked_col != -1)
        unlock_column(board, locked_col);
    if (locked_row != -1)
        unlock_row(board, locked_row);

    return res;
}

int move_ghost_charged(board_t *board, int ghost_index, char direction)
{
    ghost_t *ghost = &board->ghosts[ghost_index];
    int x = ghost->pos_x;
    int y = ghost->pos_y;
    int new_x = x;
    int new_y = y;

    ghost->charged = 0; // uncharge
    int final_index = -1;
    int result = move_ghost_charged_direction(board, ghost, direction, &new_x, &new_y, &final_index);
    if (result == INVALID_MOVE)
    {
        debug("DEFAULT CHARGED MOVE - direction = %c\n", direction);
        return INVALID_MOVE;
    }

    // Get board indices
    int old_index = get_board_index(board, ghost->pos_x, ghost->pos_y);
    int new_index = get_board_index(board, new_x, new_y);

    lock_two(board, old_index, new_index);

    char t = board->board[new_index].content;

    if (t == 'W' || t == 'M')
    {
        unlock_two(board, old_index, new_index);
        return INVALID_MOVE;
    }

    if (t == 'P')
    {
        result = find_and_kill_pacman(board, new_x, new_y);
    }

    // Update board - clear old position (restore what was there)
    board->board[old_index].content = ' '; // Or restore the dot if ghost was on one
    // Update ghost position
    ghost->pos_x = new_x;
    ghost->pos_y = new_y;
    // Update board - set new position
    board->board[new_index].content = 'M';
    unlock_two(board, old_index, new_index);
    return result;
}

int move_ghost(board_t *board, int ghost_index, command_t *command)
{
    ghost_t *ghost = &board->ghosts[ghost_index];
    int new_x = ghost->pos_x;
    int new_y = ghost->pos_y;

    // check passo
    if (ghost->waiting > 0)
    {
        ghost->waiting -= 1;
        return VALID_MOVE;
    }
    ghost->waiting = ghost->passo;

    char direction = command->command;

    if (direction == 'R')
    {
        char directions[] = {'W', 'S', 'A', 'D'};
        direction = directions[rand() % 4];
    }

    // Calculate new position based on direction
    switch (direction)
    {
    case 'W': // Up
        new_y--;
        break;
    case 'S': // Down
        new_y++;
        break;
    case 'A': // Left
        new_x--;
        break;
    case 'D': // Right
        new_x++;
        break;
    case 'C': // Charge
        ghost->current_move += 1;
        ghost->charged = 1;
        return VALID_MOVE;
    case 'T': // Wait
        if (command->turns_left == 1)
        {
            ghost->current_move += 1; // move on
            command->turns_left = command->turns;
        }
        else
            command->turns_left -= 1;
        return VALID_MOVE;
    default:
        return INVALID_MOVE; // Invalid direction
    }

    // Logic for the WASD movement
    ghost->current_move++;
    if (ghost->charged)
    {
        return move_ghost_charged(board, ghost_index, direction);
    }

    // Check boundaries
    if (!is_valid_position(board, new_x, new_y))
    {
        return INVALID_MOVE;
    }

    // Check board position
    int new_index = get_board_index(board, new_x, new_y);
    int old_index = get_board_index(board, ghost->pos_x, ghost->pos_y);

    lock_two(board, old_index, new_index);

    char target_content = board->board[new_index].content;

    // Check for walls and ghosts
    if (target_content == 'W' || target_content == 'M')
    {
        unlock_two(board, old_index, new_index);
        return INVALID_MOVE;
    }

    int result = VALID_MOVE;
    // Check for pacman
    if (target_content == 'P')
    {
        result = find_and_kill_pacman(board, new_x, new_y);
    }

    // Update board - clear old position (restore what was there)
    board->board[old_index].content = ' '; // Or restore the dot if ghost was on one

    // Update ghost position
    ghost->pos_x = new_x;
    ghost->pos_y = new_y;

    // Update board - set new position
    board->board[new_index].content = 'M';
    unlock_two(board, old_index, new_index);
    return result;
}

void *concurrent_move_ghost(void *arguments)
{
    thread_ghost_move_args_t *args = (thread_ghost_move_args_t *)arguments;
    board_t *board = args->board;
    int index = args->index;
    ghost_t *ghost = &board->ghosts[index];
    command_t *c;

    for (;;)
    {
        c = &ghost->moves[ghost->current_move % ghost->n_moves];
        move_ghost(board, index, c);
        sleep_ms(board->tempo);
        for (int i = 0; i < board->n_pacmans; i++)
        {
            if (board->pacmans[i].alive == 0)
            {
                return NULL;
            }
            if (atomic_load(&board->stop_ghosts))
                return NULL;
        }
    }
}

void kill_pacman(board_t *board, int pacman_index)
{
    debug("Killing %d pacman\n\n", pacman_index);
    pacman_t *pac = &board->pacmans[pacman_index];
    int index = pac->pos_y * board->width + pac->pos_x;

    // Remove pacman from the board
    pthread_rwlock_wrlock(&board->board[index].rwlock);
    board->board[index].content = ' ';
    pthread_rwlock_unlock(&board->board[index].rwlock);

    // Mark pacman as dead
    pac->alive = 0;
}

// Static Loading
int load_pacman(board_t *board, int points)
{

    board->board[1 * board->width + 1].content = 'P'; // Pacman
    board->pacmans[0].pos_x = 1;
    board->pacmans[0].pos_y = 1;
    board->pacmans[0].alive = 1;
    board->pacmans[0].points = points;

    return 0;
}

// Static Loading
int load_ghost(board_t *board)
{
    // Ghost 0
    board->board[3 * board->width + 1].content = 'M'; // Monster
    board->ghosts[0].pos_x = 1;
    board->ghosts[0].pos_y = 3;
    board->ghosts[0].passo = 0;
    board->ghosts[0].waiting = 0;
    board->ghosts[0].current_move = 0;
    board->ghosts[0].n_moves = 16;
    for (int i = 0; i < 8; i++)
    {
        board->ghosts[0].moves[i].command = 'D';
        board->ghosts[0].moves[i].turns = 1;
        board->ghosts[0].moves[i].turns_left = board->ghosts[0].moves[i].turns;
    }
    for (int i = 8; i < 16; i++)
    {
        board->ghosts[0].moves[i].command = 'A';
        board->ghosts[0].moves[i].turns = 1;
        board->ghosts[0].moves[i].turns_left = 1;
    }

    // Ghost 1
    board->board[2 * board->width + 4].content = 'M'; // Monster
    board->ghosts[1].pos_x = 4;
    board->ghosts[1].pos_y = 2;
    board->ghosts[1].passo = 1;
    board->ghosts[1].waiting = 1;
    board->ghosts[1].current_move = 0;
    board->ghosts[1].n_moves = 1;
    board->ghosts[1].moves[0].command = 'R'; // Random
    board->ghosts[1].moves[0].turns = 1;
    board->ghosts[1].moves[0].command = 'R';
    board->ghosts[1].moves[0].turns = 1;
    board->ghosts[1].moves[0].turns_left = 1;

    return 0;
}

void *init_ghosts(void *game_board)
{
    board_t *board = (board_t *)game_board;
    thread_ghost_move_args_t args[board->n_ghosts];

    pthread_t tid[board->n_ghosts];

    for (int i = 0; i < board->n_ghosts; i++)
    {
        args[i] = (thread_ghost_move_args_t){.board = board, .index = i};
        pthread_create(&tid[i], NULL, concurrent_move_ghost, &args[i]);
    }

    for (int i = 0; i < board->n_ghosts; i++)
    {
        pthread_join(tid[i], NULL);
    }

    return NULL;
}

int load_level(board_t *board, int points)
{

    board->height = 5;
    board->width = 10;
    board->tempo = 10;

    board->n_ghosts = 2;
    board->n_pacmans = 1;

    sprintf(board->level_name, "Static Level");

    board->board = calloc(board->width * board->height, sizeof(board_pos_t));
    board->pacmans = calloc(board->n_pacmans, sizeof(pacman_t));
    board->ghosts = calloc(board->n_ghosts, sizeof(ghost_t));

    if (!board->board || !board->pacmans || !board->ghosts)
        return -1;

    if (init_board_locks(board) != 0)
        return -1;

    for (int i = 0; i < board->height; i++)
    {
        for (int j = 0; j < board->width; j++)
        {
            if (i == 0 || j == 0 || j == (board->width - 1))
            {
                board->board[i * board->width + j].content = 'W';
            }
            else if (i == 4 && j == 8)
            {
                board->board[i * board->width + j].content = ' ';
                board->board[i * board->width + j].has_portal = 1;
            }
            else
            {
                board->board[i * board->width + j].content = ' ';
                board->board[i * board->width + j].has_dot = 1;
            }
        }
    }
    load_ghost(board);
    load_pacman(board, points);

    return 0;
}

void unload_level(board_t *board)
{
    if (board->board)
    {
        destroy_board_locks(board);
        free(board->board);
        board->board = NULL;
    }

    free(board->pacmans);
    board->pacmans = NULL;

    free(board->ghosts);
    board->ghosts = NULL;
}

void open_debug_file(char *filename)
{
    debugfile = fopen(filename, "w");
}

void close_debug_file()
{
    fclose(debugfile);
}

void debug(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    vfprintf(debugfile, format, args);
    va_end(args);

    fflush(debugfile);
}

void print_board(board_t *board)
{
    if (!board || !board->board)
    {
        debug("[%d] Board is empty or not initialized.\n", getpid());
        return;
    }

    // Large buffer to accumulate the whole output
    char buffer[8192];
    size_t offset = 0;

    offset += snprintf(buffer + offset, sizeof(buffer) - offset,
                       "=== [%d] LEVEL INFO ===\n"
                       "Dimensions: %d x %d\n"
                       "Tempo: %d\n"
                       "Pacman file: %s\n",
                       getpid(), board->height, board->width, board->tempo, board->pacman_file);

    offset += snprintf(buffer + offset, sizeof(buffer) - offset,
                       "Monster files (%d):\n", board->n_ghosts);

    for (int i = 0; i < board->n_ghosts; i++)
    {
        offset += snprintf(buffer + offset, sizeof(buffer) - offset,
                           "  - %s\n", board->ghosts_files[i]);
    }

    offset += snprintf(buffer + offset, sizeof(buffer) - offset, "\n=== BOARD ===\n");

    for (int y = 0; y < board->height; y++)
    {
        for (int x = 0; x < board->width; x++)
        {
            int idx = y * board->width + x;
            if (offset < sizeof(buffer) - 2)
            {
                buffer[offset++] = board->board[idx].content;
            }
        }
        if (offset < sizeof(buffer) - 2)
        {
            buffer[offset++] = '\n';
        }
    }

    offset += snprintf(buffer + offset, sizeof(buffer) - offset, "==================\n");

    buffer[offset] = '\0';

    debug("%s", buffer);
}
